import Ar_part1 from '@/component/Services/POLE DIGITAL & INFLUENCE/ar_part1'
import { Container } from '@mui/material'
import React from 'react'

export default function Service_ANALYSE_REPORTING() {
  return (
    <Container>
    <Ar_part1></Ar_part1>
    </Container>

  )
}
