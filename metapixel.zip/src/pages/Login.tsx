import Log from '@/component/Auth/log'
import React from 'react'

export default function Login() {
  return (
   <Log></Log>
  )
}
