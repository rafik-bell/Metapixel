import Part1 from '@/component/Services/POLE_TECHNOLOGY/part1'
import { Container, Typography } from '@mui/material'
import React from 'react'

export default function Service_CONSEIL_GESTION() {
  return (
    <Container>
        <Part1></Part1>
    </Container>
    
  )
}
