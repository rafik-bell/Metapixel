import Cd_part1 from '@/component/Services/POLE CRÉA & CONSEIL/cd_part1'
import { Container } from '@mui/material'
import React from 'react'

export default function Service_CREATION_DEVELOPPEMENT() {
  return (
    <Container>
    <Cd_part1></Cd_part1>
    </Container>
  )
}
