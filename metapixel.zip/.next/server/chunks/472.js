"use strict";
exports.id = 472;
exports.ids = [472];
exports.modules = {

/***/ 472:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Layout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(692);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(689);
// EXTERNAL MODULE: external "@mui/icons-material/Menu"
var Menu_ = __webpack_require__(365);
var Menu_default = /*#__PURE__*/__webpack_require__.n(Menu_);
// EXTERNAL MODULE: external "@mui/icons-material/Navigation"
var Navigation_ = __webpack_require__(607);
var Navigation_default = /*#__PURE__*/__webpack_require__.n(Navigation_);
;// CONCATENATED MODULE: ./src/component/Navbar.tsx






const linkStyles = {
    color: "black",
    mr: 3,
    fontSize: 18,
    textDecoration: "none",
    fontWeight: 600,
    fontFamily: "Sous-titre",
    "&:hover": {
        textDecoration: "none",
        color: "#ffa726"
    }
};
const linkStylesT = {
    color: "black",
    fontSize: 18,
    textDecoration: "none",
    fontWeight: 600,
    fontFamily: "Sous-titre",
    "&:hover": {
        textDecoration: "none",
        color: "var(--Bright_Gray)"
    }
};
const linkStyles_in_menu = {
    color: "black",
    fontSize: 18,
    margin: "5px",
    textDecoration: "none",
    fontFamily: "Sous-titre",
    "&:hover": {
        textDecoration: "none",
        color: "var(--Dark_Charcoal)"
    }
};
function Navbar() {
    const { 0: anchorEl , 1: setAnchorEl  } = (0,external_react_.useState)(null);
    const open = Boolean(anchorEl);
    const handleClick = (event)=>{
        setAnchorEl(event.currentTarget);
    };
    const handleClose = ()=>{
        setAnchorEl(null);
    };
    const { 0: anchorEl1 , 1: setAnchorEl1  } = (0,external_react_.useState)(null);
    const handleClick1 = (event)=>{
        setAnchorEl1(event.currentTarget);
    };
    const handleClose1 = ()=>{
        setAnchorEl1(null);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
        sx: {
            flexGrow: 1
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(material_.AppBar, {
                sx: {
                    bgcolor: "white"
                },
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Toolbar, {
                    sx: {
                        position: "sticky",
                        justifyContent: "space-between",
                        alignItems: "center",
                        marginTop: "10px"
                    },
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: "/Black on white AI.png",
                            alt: "Description of the image",
                            width: 170,
                            height: 48
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                            sx: {
                                display: {
                                    lg: "flex",
                                    md: "none",
                                    xs: "none"
                                },
                                flexDirection: "row",
                                alignItems: "center",
                                marginX: "2%"
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Link, {
                                    href: "\\",
                                    sx: linkStyles,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                        sx: linkStylesT,
                                        children: "Home"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                    onClick: handleClick1,
                                    sx: linkStyles,
                                    children: "Services"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Link, {
                                    href: "\\Success_story",
                                    sx: linkStyles,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                        sx: linkStylesT,
                                        children: "Success story "
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Button, {
                                    variant: "contained",
                                    href: "/Login",
                                    sx: {
                                        bgcolor: "var(--eminence)"
                                    },
                                    children: [
                                        "Join us",
                                        /*#__PURE__*/ jsx_runtime_.jsx((Navigation_default()), {})
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                            sx: {
                                display: {
                                    lg: "none"
                                }
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Button, {
                                id: "basic-button",
                                "aria-controls": open ? "basic-menu" : undefined,
                                "aria-haspopup": "true",
                                "aria-expanded": open ? "true" : undefined,
                                onClick: handleClick,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Menu_default()), {
                                    fontSize: "large"
                                })
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Menu, {
                id: "basic-menu",
                anchorEl: anchorEl,
                open: open,
                onClose: handleClose,
                MenuListProps: {
                    style: {
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center"
                    },
                    "aria-labelledby": "basic-button"
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.MenuItem, {
                        onClick: handleClose,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Link, {
                            href: "\\",
                            sx: linkStyles_in_menu,
                            children: "Home"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.MenuItem, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                            onClick: handleClick1,
                            sx: linkStyles_in_menu,
                            children: "Services"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.MenuItem, {
                        onClick: handleClose,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Link, {
                            href: "\\Success_story",
                            sx: linkStyles_in_menu,
                            children: "Success story "
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Button, {
                        variant: "contained",
                        href: "/Login",
                        sx: {
                            bgcolor: "var(--eminence)"
                        },
                        children: [
                            "Join us",
                            /*#__PURE__*/ jsx_runtime_.jsx((Navigation_default()), {})
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Menu, {
                anchorEl: anchorEl1,
                open: Boolean(anchorEl1),
                onClose: handleClose1,
                MenuListProps: {
                    "aria-labelledby": "basic-button-1"
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.MenuItem, {
                        onClick: handleClose,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Link, {
                            onClick: handleClose1,
                            sx: linkStyles_in_menu,
                            href: "\\POLE_TECHNOLOGY",
                            children: "POLE\xa0TECHNOLOGY"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.MenuItem, {
                        onClick: handleClose,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Link, {
                            onClick: handleClose1,
                            sx: linkStyles_in_menu,
                            href: "\\POLE_CREA_&_CONSEIL",
                            children: "POLE CR\xc9A & CONSEIL"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.MenuItem, {
                        onClick: handleClose,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Link, {
                            onClick: handleClose1,
                            sx: linkStyles_in_menu,
                            href: "\\POLE_DIGITAL_&_INFLUENCE",
                            children: "POLE DIGITAL & INFLUENCE"
                        })
                    })
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/component/Footer.tsx



const titele = {
    marginY: 3,
    fontSize: 25,
    fontWeight: 600,
    fontFamily: "Sous-titre"
};
const gridstyle = {
    display: "flex",
    justifyContent: "start",
    alignItems: "center"
};
function Footer() {
    return /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
        sx: {
            minWidth: "100%",
            bgcolor: "var(--eminence)",
            color: "white",
            marginTop: "30px"
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Container, {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                    container: true,
                    spacing: 1,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                        sx: gridstyle,
                        item: true,
                        lg: 12,
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: "/White PNG.png",
                            alt: "Description of the image",
                            width: 340,
                            height: 96
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                    container: true,
                    spacing: 3,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                            item: true,
                            xs: 12,
                            md: 6,
                            lg: 4,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                    sx: {
                                        ...titele,
                                        ...{
                                            color: "#ffa726"
                                        }
                                    },
                                    children: "Funnel Boost Media"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Typography, {
                                    fontFamily: "Text",
                                    sx: {
                                        marginY: 3
                                    },
                                    children: [
                                        "3201 Cherry Ridge, Suite 328",
                                        /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                        "San Antonio, Tx 78230",
                                        /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                            style: {
                                                color: "#ffa726"
                                            },
                                            children: [
                                                "(210) 503-8024",
                                                /*#__PURE__*/ jsx_runtime_.jsx("br", {})
                                            ]
                                        }),
                                        "8am-6pm Everyday"
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: "/googled.png",
                                    alt: "Description of the image",
                                    width: 200,
                                    height: 80
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                            item: true,
                            xs: 12,
                            md: 6,
                            lg: 4,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                    sx: titele,
                                    children: "Digital Marketing Services"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Typography, {
                                    fontFamily: "Text",
                                    sx: {
                                        color: "#ffa726"
                                    },
                                    children: [
                                        "Local SEO",
                                        /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                        "National SEO Services",
                                        /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                        "PPC & Search Marketing",
                                        /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                        "Website Design & Development",
                                        /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                        "News & Blog"
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                            item: true,
                            xs: 12,
                            md: 6,
                            lg: 4,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                    sx: titele,
                                    children: "Resources"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Typography, {
                                    fontFamily: "Text",
                                    sx: {
                                        color: "#ffa726"
                                    },
                                    children: [
                                        "Privacy ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                        "Terms of Service",
                                        /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                        "Contract Terms & Conditions",
                                        /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                        "Areas Of Coverage",
                                        /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                        "Careers",
                                        /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                        "Job Interview Phishing Scam Notice",
                                        /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                        "Sitemap"
                                    ]
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
}

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(853);
;// CONCATENATED MODULE: ./src/pages/layout/Layout.tsx





function Layout({ children  }) {
    const router = (0,router_.useRouter)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
        children: [
            router.pathname !== "/Login" && router.pathname !== "/Register" && /*#__PURE__*/ jsx_runtime_.jsx(Navbar, {}),
            children,
            router.pathname !== "/Login" && router.pathname !== "/Register" && /*#__PURE__*/ jsx_runtime_.jsx(Footer, {})
        ]
    });
}


/***/ })

};
;