import Ss_part1 from '@/component/Success story/Ss_part1'
import { Container } from '@mui/material'
import React from 'react'

export default function Success_story() {
  return (
    <Container>
    <Ss_part1></Ss_part1>
    </Container>
  )
}
